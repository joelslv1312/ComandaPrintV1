package com.comandaprint.v1

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var edtPedido: EditText
    private lateinit var txtPreview: TextView
    private lateinit var btnImprimir: MaterialButton

    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }
    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
    }

    private var selectedPrinterAddress: String?
        get() = prefs.getString("printer_address", null)
        set(value) { prefs.edit().putString("printer_address", value).apply() }

    private var paperWidth: Int
        get() = prefs.getInt("paper_width", 58)
        set(value) { prefs.edit().putInt("paper_width", value).apply() }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            showPrinterDialog()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtPedido = findViewById(R.id.edtPedido)
        txtPreview = findViewById(R.id.txtPreview)
        btnImprimir = findViewById(R.id.btnImprimir)

        findViewById<MaterialButton>(R.id.btnColar).setOnClickListener { pasteFromClipboard() }
        findViewById<MaterialButton>(R.id.btnLimpar).setOnClickListener {
            edtPedido.setText("")
            txtPreview.text = "Cole um pedido para gerar a prévia."
        }
        findViewById<MaterialButton>(R.id.btnConfig).setOnClickListener { showPrinterDialog() }
        btnImprimir.setOnClickListener { prepareAndPrint() }

        edtPedido.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus && edtPedido.text.isNotBlank()) updatePreview()
        }
        edtPedido.addTextChangedListener(SimpleTextWatcher { updatePreview() })
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip: ClipData? = clipboard.primaryClip
        if (clip != null && clip.itemCount > 0) {
            edtPedido.setText(clip.getItemAt(0).coerceToText(this))
            edtPedido.setSelection(edtPedido.length())
            updatePreview()
        } else {
            Toast.makeText(this, "Área de transferência vazia.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePreview() {
        val raw = edtPedido.text.toString()
        if (raw.isBlank()) {
            txtPreview.text = "Cole um pedido para gerar a prévia."
            return
        }
        txtPreview.text = OrderParser.formatPreview(raw, paperWidth)
    }

    private fun prepareAndPrint() {
        if (edtPedido.text.isBlank()) {
            Toast.makeText(this, "Cole um pedido primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        if (selectedPrinterAddress == null) {
            showPrinterDialog()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissions()
            return
        }

        btnImprimir.isEnabled = false
        Toast.makeText(this, "Enviando para a impressora...", Toast.LENGTH_SHORT).show()

        thread {
            val ok = BluetoothPrinter.print(
                adapter = bluetoothAdapter,
                address = selectedPrinterAddress!!,
                content = OrderParser.toEscPos(edtPedido.text.toString(), paperWidth)
            )
            runOnUiThread {
                btnImprimir.isEnabled = true
                Toast.makeText(
                    this,
                    if (ok) "Comanda impressa!" else "Não foi possível imprimir. Verifique a impressora.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            )
        }
    }

    private fun showPrinterDialog() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissions()
            return
        }

        val adapter = bluetoothAdapter
        if (adapter == null) {
            Toast.makeText(this, "Este celular não possui Bluetooth.", Toast.LENGTH_LONG).show()
            return
        }

        val devices = try { adapter.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }

        if (devices.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Impressora Bluetooth")
                .setMessage("Pareie a impressora nas configurações Bluetooth do celular e depois volte aqui.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        val names = devices.map { "${it.name ?: "Sem nome"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha a impressora")
            .setItems(names) { _, which ->
                selectedPrinterAddress = devices[which].address
                showPaperWidthDialog()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showPaperWidthDialog() {
        val options = arrayOf("58 mm", "80 mm")
        val checked = if (paperWidth == 80) 1 else 0
        AlertDialog.Builder(this)
            .setTitle("Largura do papel")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                paperWidth = if (which == 1) 80 else 58
                dialog.dismiss()
                updatePreview()
                Toast.makeText(this, "Configuração salva.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}

object OrderParser {
    fun formatPreview(raw: String, width: Int): String {
        val chars = if (width == 80) 48 else 32
        val lines = raw.lines().filter { it.isNotBlank() }
        val header = center("COMANDA PRINT", chars)
        val sep = "-".repeat(chars)
        val body = lines.joinToString("\n") { trimLine(it, chars) }
        return "$header\n$sep\n$body\n$sep\n${center("FIM DO PEDIDO", chars)}"
    }

    fun toEscPos(raw: String, width: Int): ByteArray {
        val chars = if (width == 80) 48 else 32
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40)) // init
        out.write(byteArrayOf(0x1B, 0x61, 0x01)) // center
        out.write("COMANDA PRINT\n".toByteArray(Charsets.UTF_8))
        out.write(byteArrayOf(0x1B, 0x61, 0x00)) // left
        out.write(("-".repeat(chars) + "\n").toByteArray())
        raw.lines().filter { it.isNotBlank() }.forEach {
            out.write((trimLine(it, chars) + "\n").toByteArray(Charsets.UTF_8))
        }
        out.write(("-".repeat(chars) + "\n").toByteArray())
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write("Obrigado!\n\n\n".toByteArray(Charsets.UTF_8))
        out.write(byteArrayOf(0x1D, 0x56, 0x00)) // cut where supported
        return out.toByteArray()
    }

    private fun trimLine(s: String, max: Int): String {
        val normalized = s.replace("\r", "").trim()
        return if (normalized.length <= max) normalized else normalized.take(max - 1) + "…"
    }

    private fun center(s: String, width: Int): String {
        if (s.length >= width) return s.take(width)
        val left = (width - s.length) / 2
        return " ".repeat(left) + s
    }
}

object BluetoothPrinter {
    private val UUID_SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun print(adapter: BluetoothAdapter?, address: String, content: ByteArray): Boolean {
        if (adapter == null) return false
        var socket: BluetoothSocket? = null
        return try {
            val device: BluetoothDevice = adapter.getRemoteDevice(address)
            socket = device.createRfcommSocketToServiceRecord(UUID_SPP)
            adapter.cancelDiscovery()
            socket.connect()
            val output: OutputStream = socket.outputStream
            output.write(content)
            output.flush()
            true
        } catch (_: Exception) {
            false
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }
}

class SimpleTextWatcher(private val callback: () -> Unit) :
    android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { callback() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
