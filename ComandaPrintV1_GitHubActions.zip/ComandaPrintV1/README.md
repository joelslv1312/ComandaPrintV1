# Comanda Print V1

Aplicativo Android para:

1. Copiar um pedido do WhatsApp.
2. Colar no aplicativo.
3. Visualizar a comanda.
4. Selecionar uma impressora Bluetooth pareada.
5. Escolher papel 58 mm ou 80 mm.
6. Enviar uma comanda ESC/POS para a impressora térmica.

## V1 atual

- Android 8.0 (API 26) ou superior.
- Impressoras Bluetooth clássicas que aceitem ESC/POS via SPP.
- Larguras de 58 mm e 80 mm.
- Pré-visualização da comanda antes da impressão.
- Configuração da impressora e largura do papel salva no aparelho.
- Permissões Bluetooth para Android 12+.

A V1 ainda não interpreta automaticamente cada campo do pedido do WhatsApp com IA. O texto colado é formatado e enviado para a impressora. Essa parte pode entrar na V2.

## Compilar pelo GitHub Actions — sem Android Studio

O projeto já contém o workflow:

`.github/workflows/build-apk.yml`

Ele instala Java 17 e Gradle 8.7 no runner do GitHub e executa `assembleDebug`. O Gradle Actions suporta a instalação de uma versão específica do Gradle pelo parâmetro `gradle-version`.

### Passo a passo

1. Crie um repositório novo no GitHub, por exemplo `ComandaPrintV1`.
2. Envie **os arquivos e pastas deste projeto para a raiz do repositório**. Não envie apenas o ZIP dentro do repositório: o GitHub precisa enxergar `app/`, `build.gradle.kts`, `settings.gradle.kts` e `.github/workflows/build-apk.yml`.
3. Depois do envio, abra a aba **Actions** do repositório.
4. Selecione **Build APK**.
5. Clique em **Run workflow**.
6. Aguarde a execução terminar com status verde.
7. Abra a execução concluída e procure **Artifacts**.
8. Baixe `ComandaPrintV1-debug`.
9. Dentro do arquivo baixado estará `app-debug.apk`.
10. Instale o APK no celular para testar.

Também deixei o workflow configurado para iniciar automaticamente quando houver um `push` na branch `main`.

## Estrutura importante

```text
ComandaPrintV1/
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── app/
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```

## Android Studio

Se preferir compilar localmente, o projeto também pode ser aberto no Android Studio. O Android Studio é a IDE oficial para desenvolvimento Android.

## Observações sobre impressoras

A V1 usa Bluetooth clássico/SPP e o comando ESC/POS. Algumas impressoras 58/80 mm usam BLE, USB ou protocolos proprietários e podem exigir uma implementação específica.

Também é possível que algumas impressoras não imprimam corretamente caracteres acentuados em UTF-8. Se isso acontecer no teste, a próxima correção será configurar a tabela de caracteres ESC/POS adequada à impressora.

O comando de corte de papel também depende de a impressora possuir cortador automático.

## Próximas melhorias planejadas

- Botão para testar a impressora.
- Logo no topo da comanda.
- Numeração automática do pedido.
- Melhor interpretação do texto copiado do WhatsApp.
- Separação automática de cliente, endereço, itens, pagamento, observações e total.
- Ajustes específicos para diferentes modelos de impressoras.
